app.service('checkWriterService', function() {
    this.writerEvaluator = function(numExp) {

        var thousandPlace = ['', 'thousand', 'million', 'billion', 'trillion'];
        var digit = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
        var tenthPlace = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
        var twentiethPlace = ['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
        numExp = numExp.toString();
        numExp = numExp.replace(/[\, ]/g, '');
        if (numExp > 0) {
            var x = numExp.indexOf('.');
            if (x == -1) x = numExp.length;
            var n = numExp.split('');
            var str = '';
            var sk = 0;
            for (var i = 0; i < x; i++) {
                if ((x - i) % 3 == 2) {
                    if (n[i] == '1') {
                        str += tenthPlace[Number(n[i + 1])] + ' ';
                        i++;
                        sk = 1;
                    } else if (n[i] != 0) {
                        str += twentiethPlace[n[i] - 2] + ' ';
                        sk = 1;
                    }
                } else if (n[i] != 0) {
                    str += digit[n[i]] + ' ';
                    if ((x - i) % 3 == 0) str += 'hundred ';
                    sk = 1;
                }
                if ((x - i) % 3 == 1) {
                    if (sk) str += thousandPlace[(x - i - 1) / 3] + ' ';
                    sk = 0;
                }
            }
            if (x != numExp.length) {
                splitNum = numExp.split(".");

                if (splitNum[1] != 0) {

                    if (/^\d$/.test(splitNum[1])) {


                        if (splitNum[0] == 0) {
                            str += splitNum[1] + "0" + "/100";
                        } else {
                            str += 'and ' + splitNum[1] + "0" + "/100";
                        }

                    } else {
                        if (splitNum[0] == 0) {
                            str += splitNum[1] + "/100";
                        } else {
                            str += 'and ' + splitNum[1] + "/100";
                        }


                    }

                }
            }

            str1 = str.split(" ")[0];
            str1 = str.charAt(0).toUpperCase() + str.slice(1);
            return str1.replace(/\numExp+/g, ' ');

        } else {
            return 'not a number';
        }
    }

});