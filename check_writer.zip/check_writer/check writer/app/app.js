var app = angular.module('writerApp', []);

