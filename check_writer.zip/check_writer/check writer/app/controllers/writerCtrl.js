app.controller('writerCtrl', ['$scope', 'checkWriterService', function($scope, checkWriterService) {
	$scope.writerExp="";
	$scope.evaluate = function() {
		$scope.output = checkWriterService.writerEvaluator($scope.writerExp);
	}
    
}]);