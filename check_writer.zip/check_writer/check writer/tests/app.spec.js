describe('Check Writer', function(){
	beforeEach(angular.mock.module('writerApp'));

    var $controller, $scope, controller;;
	
    beforeEach(inject(function(_$controller_){
    $controller = _$controller_;
    }));
	 
   beforeEach(function() {
      $scope = {};
      controller = $controller('writerCtrl', { $scope: $scope });
    });
	
   it('should return one hundred twenty three if the input expression is 123', function() {
      $scope.expression = '123';
      $scope.output = $scope.writerEvaluator($scope.expression);
      expect($scope.output).toEqual(one hundred twenty three);
    });

    it('should return fifty six and 45/100 if the input expression is 56.45', function() {
      $scope.expression = '56.45';
      $scope.output = $scope.writerEvaluator($scope.expression);
      expect($scope.output).toEqual(fifty six and 45/100);
    });
	
    it('should return one hundred twenty five if the input expression is 125.000', function() {
      $scope.expression = '125.000';
      $scope.output = $scope.writerEvaluator($scope.expression);
      expect($scope.output).toEqual(one hundred twenty five);
    });
  
});